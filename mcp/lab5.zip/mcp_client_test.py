import asyncio
import sys
from mcp import Client

MCP_URL = "http://127.0.0.1:8000/mcp"

async def main():
    tool_name = sys.argv[1] if len(sys.argv) > 1 else "list"
    value = sys.argv[2] if len(sys.argv) > 2 else None

    async with Client(MCP_URL) as client:
        if tool_name == "list":
            tools = await client.list_tools()
            print("MCP tools:")
            for tool in tools.tools:
                print(f" - {tool.name}")
            return

        args = {}
        if tool_name in {"customer", "invoice", "remittance", "payment_history", "erp"}:
            key = {
                "customer": "customer_id",
                "invoice": "invoice_id",
                "remittance": "remittance_id",
                "payment_history": "customer_id",
                "erp": "payment_id",
            }[tool_name]
            args[key] = value
            actual = {
                "customer": "customer_lookup",
                "invoice": "invoice_lookup",
                "remittance": "remittance_retrieval",
                "payment_history": "payment_history",
                "erp": "erp_transaction_lookup",
            }[tool_name]
        elif tool_name == "rules":
            actual = "matching_rules"
        else:
            raise SystemExit("Use: list | customer | invoice | remittance | payment_history | erp | rules")

        result = await client.call_tool(actual, args)

        if result.is_error:
            print("MCP tool error:")
            print(result.content)
        else:
            if result.structured_content is not None:
                print(result.structured_content)
            else:
                for item in result.content:
                    if hasattr(item, "text"):
                        print(item.text)

if __name__ == "__main__":
    asyncio.run(main())
