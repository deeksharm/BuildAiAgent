import argparse
import json
import ast
import uvicorn
import asyncio

from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes import create_agent_card_routes, create_jsonrpc_routes
from a2a.server.tasks import InMemoryTaskStore, TaskUpdater
from a2a.helpers import new_task_from_user_message, new_text_message, new_text_part
from a2a.types import AgentCapabilities, AgentCard, AgentInterface, AgentSkill, TaskState
from starlette.applications import Starlette

import asyncio
from mcp import Client

MCP_URL = "http://127.0.0.1:8000/mcp"

AGENTS = {
    "remittance": {
        "name": "Remittance Agent",
        "port": 10001,
        "skill": "Retrieve and normalize remittance information.",
    },
    "matching": {
        "name": "Matching Agent",
        "port": 10002,
        "skill": "Identify invoice candidates for a remittance.",
    },
    "smart_matching": {
        "name": "Smart Matching Agent",
        "port": 10003,
        "skill": "Apply enterprise matching rules and return a confidence decision.",
    },
    "exception": {
        "name": "Exception Agent",
        "port": 10004,
        "skill": "Classify exceptions and recommend human review.",
    },
}

async def mcp_call(tool: str, args: dict) -> dict:
    async with Client(MCP_URL) as client:
        result = await client.call_tool(tool, args)

        # 1. Check for standard structured data
        if result.structured_content:
            return result.structured_content

        # 2. Iterate through text responses
        for item in result.content:
            if hasattr(item, "text") and item.text:
                
                # Attempt A: Strict JSON parsing
                try:
                    return json.loads(item.text)
                except json.JSONDecodeError:
                    pass
                
                # Attempt B: Python literal evaluation (handles single quotes)
                try:
                    return ast.literal_eval(item.text)
                except Exception:
                    pass
        
        # 3. If we get here, log it so it doesn't fail silently again!
        print(f"\n[ERROR] MCP call to {tool} failed to parse data. Raw output: {result.content}\n")
        return {}

async def business_logic(agent: str, payload: dict) -> dict:
    if agent == "remittance":
        remittance_id = payload.get("remittance_id")
        return await mcp_call("remittance_retrieval", {"remittance_id": remittance_id})

    if agent == "matching":
        invoice_id = payload.get("invoice_id")
        return await mcp_call("invoice_lookup", {"invoice_id": invoice_id})

    if agent == "smart_matching":
        rules = await mcp_call("matching_rules", {})
        remittance = payload["remittance"]
        invoice = payload["invoice"]

        print("\n=== PAYLOAD REVEAL ===")
        print(f"REMITTANCE DATA: {remittance}")
        print(f"INVOICE DATA: {invoice}")
        print("======================\n")

        # Safely extract customer IDs without triggering a KeyError
        remit_cust = remittance.get("customer_id") if isinstance(remittance, dict) else None
        
        # Check both potential key names for the invoice
        inv_cust = None
        if isinstance(invoice, dict):
            inv_cust = invoice.get("customer_id", invoice.get("customer"))

        # Safely evaluate the match
        customer_match = (remit_cust == inv_cust) and (remit_cust is not None)
        
        amount_match = abs(float(remittance["amount"]) - float(invoice["amount"])) < 0.01

        if customer_match and amount_match:
            return {
                "status": "MATCHED",
                "confidence": float(rules["exact_match_confidence"]),
                "reason": "Customer and amount match the enterprise matching rules.",
                "decision": "ACCEPT",
            }

        return {
            "status": "EXCEPTION",
            "confidence": 0.40,
            "reason": "Customer or amount mismatch.",
            "decision": "HUMAN_REVIEW",
        }

    if agent == "exception":
        reason = payload.get("reason", "Unresolved matching exception")
        return {
            "status": "EXCEPTION",
            "reason": reason,
            "decision": "HUMAN_REVIEW",
            "posting_executed": False,
        }

    raise ValueError(f"Unknown agent: {agent}")

class EnterpriseAgentExecutor(AgentExecutor):
    def __init__(self, agent_name: str):
        self.agent_name = agent_name

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        task = context.current_task
        if task is None:
            task = new_task_from_user_message(context.message)
            await event_queue.enqueue_event(task)

        updater = TaskUpdater(event_queue, task.id, task.context_id)
        await updater.update_status(
            state=TaskState.TASK_STATE_WORKING,
            message=new_text_message(f"{AGENTS[self.agent_name]['name']} processing"),
        )

        raw = context.get_user_input()
        payload = json.loads(raw)
        result = await business_logic(self.agent_name, payload)

        await updater.add_artifact(
            parts=[new_text_part(text=json.dumps(result), media_type="application/json")]
        )
        await updater.update_status(state=TaskState.TASK_STATE_COMPLETED)

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        await event_queue.enqueue_event(
            new_text_message(f"{AGENTS[self.agent_name]['name']} cancellation requested")
        )

def create_app(agent_name: str, port: int):
    meta = AGENTS[agent_name]

    skill = AgentSkill(
        id=agent_name,
        name=meta["name"],
        description=meta["skill"],
        input_modes=["text/plain"],
        output_modes=["application/json"],
        tags=["mcp", "a2a", "remittance"],
        examples=["process remittance"],
    )

    card = AgentCard(
        name=meta["name"],
        description=meta["skill"],
        version="1.0.0",
        default_input_modes=["text/plain"],
        default_output_modes=["application/json"],
        capabilities=AgentCapabilities(streaming=False),
        supported_interfaces=[
            AgentInterface(
                protocol_binding="JSONRPC",
                url=f"http://127.0.0.1:{port}",
                protocol_version="1.0",
            )
        ],
        skills=[skill],
    )

    handler = DefaultRequestHandler(
    agent_executor=EnterpriseAgentExecutor(agent_name),
    task_store=InMemoryTaskStore(),
    agent_card=card,
    )

    routes = []
    routes.extend(create_agent_card_routes(card))
    routes.extend(create_jsonrpc_routes(handler, "/"))

    return Starlette(routes=routes)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--agent", choices=AGENTS.keys(), required=True)
    parser.add_argument("--port", type=int, required=True)
    args = parser.parse_args()

    print(f"{AGENTS[args.agent]['name']} starting on port {args.port}")
    uvicorn.run(create_app(args.agent, args.port), host="127.0.0.1", port=args.port)

if __name__ == "__main__":
    main()
