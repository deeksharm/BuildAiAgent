from pathlib import Path

required = [
    "requirements.txt",
    "mcp_server.py",
    "mcp_client_test.py",
    "a2a_agents.py",
    "a2a_client.py",
    "e2e.py",
    "test_cases.py",
    "data/enterprise_data.json",
]

missing = [p for p in required if not Path(p).exists()]

if missing:
    print("Missing files:")
    for item in missing:
        print(" -", item)
    raise SystemExit(1)

print("Lab package validation: PASS")
print(f"Required files found: {len(required)}")
