from pathlib import Path
import json
from mcp.server import MCPServer

DATA = json.loads((Path(__file__).parent / "data" / "enterprise_data.json").read_text())

mcp = MCPServer(
    "Remittance Enterprise Tools",
    instructions="Controlled enterprise access for Remittance-to-Cash operations."
)

@mcp.tool()
def customer_lookup(customer_id: str) -> dict:
    """Look up a customer through the controlled enterprise interface."""
    customer = DATA["customers"].get(customer_id)
    if not customer:
        return {"error": "Customer not found", "customer_id": customer_id}
    return customer

@mcp.tool()
def invoice_lookup(invoice_id: str) -> dict:
    """Look up an invoice through the controlled enterprise interface."""
    invoice = DATA["invoices"].get(invoice_id)
    if not invoice:
        return {"error": "Invoice not found", "invoice_id": invoice_id}
    return invoice

@mcp.tool()
def payment_history(customer_id: str) -> dict:
    """Retrieve payment history for a customer."""
    return {
        "customer_id": customer_id,
        "payments": DATA["payment_history"].get(customer_id, [])
    }

@mcp.tool()
def remittance_retrieval(remittance_id: str) -> dict:
    """Retrieve remittance information."""
    remittance = DATA["remittances"].get(remittance_id)
    if not remittance:
        return {"error": "Remittance not found", "remittance_id": remittance_id}
    return remittance

@mcp.tool()
def matching_rules() -> dict:
    """Retrieve enterprise payment matching rules."""
    return DATA["matching_rules"]

@mcp.tool()
def erp_transaction_lookup(payment_id: str) -> dict:
    """Retrieve ERP transaction state without performing a posting."""
    tx = DATA["erp_transactions"].get(payment_id)
    if not tx:
        return {"error": "ERP transaction not found", "payment_id": payment_id}
    return tx

if __name__ == "__main__":
    print("MCP server starting on http://127.0.0.1:8000/mcp")
    print("Tools registered: 6")
    mcp.run(
        transport="streamable-http",
        host="127.0.0.1",
        port=8000,
        stateless_http=True,
        json_response=True,
    )
