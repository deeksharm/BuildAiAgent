# Lab 5 — MCP & A2A Enterprise Integration

This package contains the executable code and deterministic enterprise dataset for the lab.

Architecture:
Remittance Agent -> Matching Agent -> Smart Matching Agent -> Exception Agent
                                      |
                               MCP Enterprise Tools
                                      |
                Customer | Invoice | Payment | Remittance | ERP

## Quick start

1. Create/activate a Python 3.11+ virtual environment.
2. Install:
   `pip install -r requirements.txt`
3. Terminal 1:
   `python mcp_server.py`
4. Terminal 2:
   `python mcp_client_test.py`
5. Start the four A2A agents in separate terminals:
   `python a2a_agents.py --agent remittance --port 10001`
   `python a2a_agents.py --agent matching --port 10002`
   `python a2a_agents.py --agent smart_matching --port 10003`
   `python a2a_agents.py --agent exception --port 10004`
6. Terminal 6:
   `python e2e.py PAY-TEST-001`
7. Validate exception:
   `python e2e.py PAY-TEST-005`
8. Run all five:
   `python test_cases.py`

The MCP server uses Streamable HTTP at:
`http://127.0.0.1:8000/mcp`

The A2A agents expose Agent Cards at:
`http://127.0.0.1:<port>/.well-known/agent-card.json`

The dataset is intentionally deterministic so the lab can be validated without a live ERP.
