import json
import uuid

import httpx


async def send(agent_url: str, payload: dict) -> dict:
    """
    Send a non-streaming A2A SendMessage request directly
    using JSON-RPC 2.0.
    """

    message = {
    "role": "ROLE_USER",
    "parts": [
        {
            "text": json.dumps(payload)
        }
    ],
    "messageId": uuid.uuid4().hex,
    }

    request = {
        "jsonrpc": "2.0",
        "id": uuid.uuid4().hex,
        "method": "SendMessage",
        "params": {
            "message": message
        },
    }

    async with httpx.AsyncClient(timeout=30.0) as client:

        response = await client.post(
            agent_url,
            json=request,
            headers={
                "Content-Type": "application/json",
                "A2A-Version": "1.0",
            },
        )

        response.raise_for_status()

        body = response.json()

    if "error" in body:
        raise RuntimeError(
            f"A2A error from {agent_url}: {body['error']}"
        )

    result = body.get("result", {})

    # A2A SendMessage returns either a Task or a Message.
    task = result.get("task")

    if task:
        artifacts = task.get("artifacts", [])

        for artifact in artifacts:

            for part in artifact.get("parts", []):

                if "text" in part:
                    text = part["text"]

                    try:
                        return json.loads(text)
                    except json.JSONDecodeError:
                        return {"text": text}

    # Message-only response
    message = result.get("message")

    if message:
        for part in message.get("parts", []):

            if "text" in part:
                text = part["text"]

                try:
                    return json.loads(text)
                except json.JSONDecodeError:
                    return {"text": text}

    raise RuntimeError(
        f"No business response received from A2A agent: {agent_url}\n"
        f"Response: {json.dumps(body, indent=2)}"
    )