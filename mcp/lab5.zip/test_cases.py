import subprocess
import sys

TESTS = [
    ("PAY-TEST-001", "MATCHED"),
    ("PAY-TEST-002", "MATCHED"),
    ("PAY-TEST-003", "MATCHED"),
    ("PAY-TEST-004", "MATCHED"),
    ("PAY-TEST-005", "HUMAN_REVIEW"),
]

for payment_id, expected in TESTS:
    print("=" * 70)
    print(f"TEST: {payment_id} | EXPECTED: {expected}")
    print("=" * 70)

    result = subprocess.run(
        [sys.executable, "e2e.py", payment_id],
        text=True,
        capture_output=True,
    )

    print(result.stdout)
    if result.returncode != 0:
        print(result.stderr)
        print(f"{payment_id}: FAIL")
        continue

    output = result.stdout
    passed = (
        ("MATCHED" in output if expected == "MATCHED"
         else "HUMAN_REVIEW" in output)
    )
    print(f"{payment_id}: {'PASS' if passed else 'FAIL'}")
