import asyncio
import json
import sys

from a2a_client import send

DATA = {
    "PAY-TEST-001": {"remittance_id": "REM-10001", "invoice_id": "INV-10001"},
    "PAY-TEST-002": {"remittance_id": "REM-10002", "invoice_id": "INV-10002"},
    "PAY-TEST-003": {"remittance_id": "REM-10003", "invoice_id": "INV-10003"},
    "PAY-TEST-004": {"remittance_id": "REM-10004", "invoice_id": "INV-10001"},
    "PAY-TEST-005": {"remittance_id": "REM-10005", "invoice_id": "INV-10004"},
}

async def run(payment_id: str):
    if payment_id not in DATA:
        raise SystemExit(f"Unknown payment: {payment_id}")

    case = DATA[payment_id]

    print(f"Transaction: {payment_id}")

    remittance = await send(
        "http://127.0.0.1:10001",
        {"remittance_id": case["remittance_id"]},
    )
    print("A2A: Remittance Agent -> SUCCESS")

    invoice = await send(
        "http://127.0.0.1:10002",
        {"invoice_id": case["invoice_id"]},
    )
    print("A2A: Matching Agent -> SUCCESS")

    if payment_id == "PAY-TEST-005":
        # Controlled mismatch test: deliberately alter customer identity.
        invoice = dict(invoice)
        invoice["customer_id"] = "CUST-005"

    decision = await send(
        "http://127.0.0.1:10003",
        {"remittance": remittance, "invoice": invoice},
    )
    print(f"A2A: Smart Matching Agent -> {decision.get('status')}")

    if decision.get("status") == "EXCEPTION":
        exception = await send(
            "http://127.0.0.1:10004",
            {"reason": decision.get("reason", "Low confidence")},
        )
        print("A2A: Exception Agent -> HUMAN_REVIEW")
        print(json.dumps(exception, indent=2))
    else:
        print(json.dumps(decision, indent=2))

    print("Payment posting: NOT EXECUTED")

if __name__ == "__main__":
    payment_id = sys.argv[1] if len(sys.argv) > 1 else "PAY-TEST-001"
    asyncio.run(run(payment_id))
