import pandas as pd
from langgraph.graph import StateGraph, END
from graph.state import RemittanceState
from deterministic.parser import DocumentIngestionParser
from deterministic.rules_engine import DeterministicRulesEngine
from agents.exception_agent import RemittanceExceptionAgent

# Initialize engines
rules_engine = DeterministicRulesEngine()
agent = RemittanceExceptionAgent()

# Node Functions
def ingestion_node(state: RemittanceState) -> RemittanceState:
    parsed = DocumentIngestionParser.parse_document(state["raw_document"])
    return {**state, "extracted_data": parsed}

def validation_node(state: RemittanceState) -> RemittanceState:
    errors = rules_engine.validate_transaction(state["extracted_data"])
    return {**state, "validation_errors": errors}

def deterministic_match_node(state: RemittanceState) -> RemittanceState:
    if state.get("validation_errors"):
        return state
        
    extracted = state["extracted_data"]
    
    # 1. Exact match attempt
    res = rules_engine.exact_match(extracted)
    if res:
        return {
            **state,
            "deterministic_result": res,
            "final_confidence": res["confidence"],
            "explanation": res["reason"],
            "next_best_action": "Automatically post cash to ledger."
        }
        
    # 2. Rule / Fuzzy match attempt
    res = rules_engine.rule_fuzzy_match(extracted)
    if res:
        return {
            **state,
            "deterministic_result": res,
            "final_confidence": res["confidence"],
            "explanation": res["reason"],
            "next_best_action": "Automatically post cash with fuzzy matched identity."
        }
        
    return {**state, "deterministic_result": None}

def ai_smart_match_node(state: RemittanceState) -> RemittanceState:
    invoices_json = rules_engine.invoices_df.to_json(orient="records")
    rec = agent.evaluate_exception(state["extracted_data"], invoices_json)
    
    return {
        **state,
        "ai_recommendation": rec,
        "final_confidence": rec.get("confidence_score", 0.0),
        "explanation": rec.get("explanation", ""),
        "next_best_action": rec.get("next_best_action", "")
    }

def confidence_gate_node(state: RemittanceState) -> RemittanceState:
    conf = state.get("final_confidence", 0.0)
    
    if conf >= 0.85:
        decision = "AUTO_POST"
    else:
        decision = "HITL"
        
    return {**state, "routing_decision": decision}

# Conditional Routers
def route_after_validation(state: RemittanceState) -> str:
    if state.get("validation_errors"):
        return "confidence_gate"
    return "deterministic_match"

def route_after_deterministic(state: RemittanceState) -> str:
    if state.get("deterministic_result"):
        return "confidence_gate"
    return "ai_smart_match"

# Assemble Workflow Graph
workflow = StateGraph(RemittanceState)

workflow.add_node("ingestion", ingestion_node)
workflow.add_node("validation", validation_node)
workflow.add_node("deterministic_match", deterministic_match_node)
workflow.add_node("ai_smart_match", ai_smart_match_node)
workflow.add_node("confidence_gate", confidence_gate_node)

workflow.set_entry_point("ingestion")
workflow.add_edge("ingestion", "validation")
workflow.add_conditional_edges("validation", route_after_validation, {
    "confidence_gate": "confidence_gate",
    "deterministic_match": "deterministic_match"
})
workflow.add_conditional_edges("deterministic_match", route_after_deterministic, {
    "confidence_gate": "confidence_gate",
    "ai_smart_match": "ai_smart_match"
})
workflow.add_edge("ai_smart_match", "confidence_gate")
workflow.add_edge("confidence_gate", END)

app_graph = workflow.compile()
