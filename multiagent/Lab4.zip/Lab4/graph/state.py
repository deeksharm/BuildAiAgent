from typing import TypedDict, List, Dict, Any, Optional

class RemittanceState(TypedDict):
    raw_document: Dict[str, Any]
    extracted_data: Dict[str, Any]
    validation_errors: List[str]
    deterministic_result: Optional[Dict[str, Any]]
    ai_recommendation: Optional[Dict[str, Any]]
    final_confidence: float
    routing_decision: str  # AUTO_POST, HITL, REJECT
    explanation: str
    next_best_action: str
