import os
import json
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

load_dotenv()

class RemittanceExceptionAgent:
    def __init__(self):
        self.llm = ChatOpenAI(
            model=os.getenv("MODEL_DEPLOYMENT_NAME", "gpt-5-mini"),
            openai_api_key=os.getenv("FOUNDRY_API_KEY"),
            openai_api_base=os.getenv("FOUNDRY_ENDPOINT"),
            temperature=0.0
        )
        
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert AI Remittance Exception Agent in cash application workflows.
Analyze payment notes, extracted details, and ERP invoices to explain short-pays, partial matches, or discrepancies.

Return ONLY a valid JSON object matching this schema:
{{
  "recommended_invoice_id": "string or null",
  "confidence_score": float (0.0 to 1.0),
  "explanation": "Detailed explanation of short pay, variance, or match rationale",
  "next_best_action": "Clear actionable next step for accounting/HITL team"
}}"""),
            ("user", """ERP Invoices Ledger:
{ledger}

Extracted Remittance Information:
{extracted}

Analyze discrepancy and provide match recommendation.""")
        ])

    def evaluate_exception(self, extracted: dict, invoices_df_json: str) -> dict:
        chain = self.prompt | self.llm
        response = chain.invoke({
            "ledger": invoices_df_json,
            "extracted": json.dumps(extracted)
        })
        
        try:
            cleaned = response.content.strip().strip("```json").strip("```").strip()
            return json.loads(cleaned)
        except Exception as e:
            return {
                "recommended_invoice_id": None,
                "confidence_score": 0.0,
                "explanation": f"Failed to parse agent output: {str(e)}",
                "next_best_action": "Escalate manual review."
            }
