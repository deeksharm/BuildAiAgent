import json
from graph.remittance_graph import app_graph

def run_lab4():
    print("=" * 80)
    print(" LAB 4 — REMITTANCE MULTI-AGENT SOLUTION RUNNER")
    print("=" * 80)
    
    with open("data/raw_remittance.json") as f:
        documents = json.load(f)
        
    for doc in documents:
        initial_state = {
            "raw_document": doc,
            "extracted_data": {},
            "validation_errors": [],
            "deterministic_result": None,
            "ai_recommendation": None,
            "final_confidence": 0.0,
            "routing_decision": "PENDING",
            "explanation": "",
            "next_best_action": ""
        }
        
        result = app_graph.invoke(initial_state)
        
        print(f"\n▶ DOCUMENT ID: {doc['document_id']}")
        print(f"  Sender Name       : {result['extracted_data'].get('sender_name')}")
        print(f"  Payment Amount    : ${result['extracted_data'].get('payment_amount')}")
        print(f"  Final Confidence  : {result['final_confidence']:.2f}")
        print(f"  Routing Decision  : {result['routing_decision']}")
        print(f"  Explanation       : {result['explanation']}")
        print(f"  Next Best Action  : {result['next_best_action']}")
        print("-" * 80)

if __name__ == "__main__":
    run_lab4()
