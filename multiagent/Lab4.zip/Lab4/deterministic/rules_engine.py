import pandas as pd
from difflib import SequenceMatcher

class DeterministicRulesEngine:
    def __init__(self, invoices_csv="data/invoices.csv", customers_csv="data/customers.csv"):
        self.invoices_df = pd.read_csv(invoices_csv)
        self.customers_df = pd.read_csv(customers_csv)

    def validate_transaction(self, extracted: dict) -> list:
        """Validates fundamental transaction rules (amounts > 0, valid structures)."""
        errors = []
        if extracted["payment_amount"] <= 0:
            errors.append("Invalid payment amount: Must be greater than 0.")
        if not extracted["sender_name"]:
            errors.append("Missing sender identity.")
        return errors

    def exact_match(self, extracted: dict) -> dict:
        """Attempts exact key matching against ERP ledger."""
        inv_ref = extracted.get("invoice_reference")
        amt = extracted.get("payment_amount")
        
        if not inv_ref:
            return None
            
        matched = self.invoices_df[
            (self.invoices_df["invoice_id"] == inv_ref) & 
            (self.invoices_df["amount_due"] == amt)
        ]
        
        if len(matched) == 1:
            row = matched.iloc[0]
            return {
                "matched_invoice_id": row["invoice_id"],
                "customer_id": row["customer_id"],
                "confidence": 1.0,
                "match_type": "EXACT_MATCH",
                "reason": "Exact match on Invoice ID and Payment Amount."
            }
        return None

    def rule_fuzzy_match(self, extracted: dict) -> dict:
        """Attempts fuzzy string matching on customer name and invoice key substrings."""
        sender = extracted.get("sender_name", "")
        amt = extracted.get("payment_amount", 0.0)
        inv_ref = extracted.get("invoice_reference", "") or ""
        
        # 1. Fuzzy match customer name
        best_cust = None
        highest_ratio = 0.0
        for _, cust in self.customers_df.iterrows():
            ratio = max(
                SequenceMatcher(None, sender.lower(), cust["official_name"].lower()).ratio(),
                SequenceMatcher(None, sender.lower(), cust["alias"].lower()).ratio()
            )
            if ratio > highest_ratio:
                highest_ratio = ratio
                best_cust = cust
                
        if highest_ratio >= 0.75 and best_cust is not None:
            # Look for open invoices for this matched customer
            cust_invoices = self.invoices_df[self.invoices_df["customer_id"] == best_cust["customer_id"]]
            for _, inv in cust_invoices.iterrows():
                # Check for exact amount match or stripped invoice ID match
                clean_ref = inv_ref.split("-X")[0] if "-X" in inv_ref else inv_ref
                if inv["invoice_id"] == clean_ref and abs(inv["amount_due"] - amt) < 0.01:
                    return {
                        "matched_invoice_id": inv["invoice_id"],
                        "customer_id": best_cust["customer_id"],
                        "confidence": 0.90,
                        "match_type": "RULE_FUZZY_MATCH",
                        "reason": f"Matched via fuzzy customer resolution ({best_cust['official_name']}) & reference normalization."
                    }
        return None
