import json
import re

class DocumentIngestionParser:
    """Ingests raw remittance documents and extracts structured key-value entities."""
    
    @staticmethod
    def parse_document(doc_item: dict) -> dict:
        raw_text = doc_item.get("raw_text", "")
        
        # Regex parsing for key entities
        sender_match = re.search(r"Sender:\s*(.*)", raw_text)
        inv_match = re.search(r"Invoice Ref:\s*(.*)", raw_text)
        notes_match = re.search(r"Notes:\s*(.*)", raw_text)
        
        extracted = {
            "document_id": doc_item.get("document_id"),
            "sender_name": sender_match.group(1).strip() if sender_match else None,
            "invoice_reference": inv_match.group(1).strip() if inv_match else None,
            "payment_amount": float(doc_item.get("payment_amount", 0.0)),
            "payment_ref": doc_item.get("payment_ref"),
            "notes": notes_match.group(1).strip() if notes_match else None,
            "raw_text": raw_text
        }
        return extracted

if __name__ == "__main__":
    with open("data/raw_remittance.json") as f:
        docs = json.load(f)
    for d in docs:
        parsed = DocumentIngestionParser.parse_document(d)
        print(f"Extracted [{parsed['document_id']}]: Sender={parsed['sender_name']} | Ref={parsed['invoice_reference']} | Amount=${parsed['payment_amount']}")
