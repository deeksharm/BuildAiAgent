"""
agents.py — Specialist Agent Node Functions
Lab 2: Multi-Agent Orchestration with LangGraph + Azure AI Foundry

Each function is a LangGraph *node* — it receives the shared RemittanceState,
performs its specialist task (using tools and/or structured outputs via
Azure OpenAI), and returns a state-update dict.

Agent hierarchy:
    Supervisor  →  Ingestion Agent
                →  Remittance Processing Agent
                →  Payment Matching Agent
                →  Smart Matching Agent
                →  HITL Review Node
                →  Error Handler Node
"""

import json
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from openai import AzureOpenAI

from config import get_llm
from models import RoutingDecision, AgentTarget
from tools import (
    extract_remittance_data,
    validate_remittance,
    lookup_invoice,
    match_payment,
    search_erp_for_alternatives,
)
import os

# ── Confidence Thresholds ────────────────────────────────────────────────
CONFIDENCE_THRESHOLD_AUTO = 0.85   # Auto-approve if above this
CONFIDENCE_THRESHOLD_HITL = 0.50   # Escalate to HITL if below this

_SUPERVISOR_AGENT = None

# =========================================================================
# 1.  SUPERVISOR AGENT
# =========================================================================

def supervisor_node(state: dict) -> dict:
    """
    Central orchestrator. Analyses pipeline state and routes to the next
    specialist agent using the Azure UI Managed Agent (via AIProjectClient).
    """
    global _SUPERVISOR_AGENT

    system_prompt = """You are the Supervisor Agent for a remittance processing pipeline.
Analyse the current pipeline state and decide which specialist agent should execute next.

Available agents and when to route to each:
• ingestion_agent      — raw_document exists but remittance_data is empty
• remittance_agent     — remittance_data exists but payment_records is empty
• matching_agent       — payment_records exist but match_results is empty
• smart_matching_agent — match_results exist AND there are unmatched items
• hitl_review          — overall confidence < 0.50 OR errors cannot be auto-resolved
• complete             — all items matched with confidence ≥ 0.85 and no errors

Routing rules:
1. Always start with ingestion_agent when raw_document is present but unprocessed.
2. Follow the linear pipeline: ingestion → remittance → matching → smart → HITL/complete.
3. Never skip an earlier stage if its output is missing.
4. If retry_count ≥ 3, route to hitl_review regardless.
5. Route to complete only when ALL items are resolved.

You MUST return your response as a valid JSON object exactly matching this format: {"next_agent": "<agent_name>", "reasoning": "<text>", "confidence": <float>}"""

    state_summary = {
        "has_raw_document": bool(state.get("raw_document")),
        "has_remittance_data": bool(state.get("remittance_data")),
        "has_payment_records": bool(state.get("payment_records")),
        "has_match_results": bool(state.get("match_results")),
        "current_agent": state.get("current_agent", "none"),
        "retry_count": state.get("retry_count", 0),
        "errors": state.get("error_log", []),
        "confidence_scores": state.get("confidence_scores", {}),
        "requires_hitl": state.get("requires_hitl", False),
    }

    try:
        # Use Azure OpenAI directly (same credentials as the LLM)
        openai_client = AzureOpenAI(
            api_key=os.environ["AZURE_OPENAI_API_KEY"],
            api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2025-04-01-preview"),
            azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        )
        
        # 1. Create agent in Azure UI (runs once per session)
        if not _SUPERVISOR_AGENT:
            _SUPERVISOR_AGENT = openai_client.beta.assistants.create(
                model=os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"],
                name="SupervisorAgent",
                instructions=system_prompt
            )
            print(f"  [Azure] ✓ SupervisorAgent created in Azure UI (id: {_SUPERVISOR_AGENT.id})")
            
        # 2. Create Thread & Send Message
        thread = openai_client.beta.threads.create()
        openai_client.beta.threads.messages.create(
            thread_id=thread.id,
            role="user",
            content=f"Current pipeline state:\n{json.dumps(state_summary, indent=2)}\n\nDecide the next agent to route to. Return ONLY JSON."
        )
        
        # 3. Run and Poll
        run = openai_client.beta.threads.runs.create_and_poll(
            thread_id=thread.id, 
            assistant_id=_SUPERVISOR_AGENT.id
        )
        
        if run.status == "failed":
            raise Exception(f"Agent Run failed: {run.last_error}")
            
        messages = openai_client.beta.threads.messages.list(thread_id=thread.id)
        latest_msg = messages.data[0].content[0].text.value
        
        # 4. Parse JSON Output
        raw_json = json.loads(latest_msg.strip("`").replace("json\n", "").strip())
        decision = RoutingDecision(**raw_json)
        
    except Exception as e:
        # Fallback if Azure Assistants API fails
        print(f"\n[Warning] Azure UI Agent creation failed ({e}). Falling back to local LLM...")
        llm = get_llm(temperature=1)
        structured_llm = llm.with_structured_output(RoutingDecision)
        
        decision = structured_llm.invoke([
            SystemMessage(content=system_prompt),
            HumanMessage(content=f"Current pipeline state:\n{json.dumps(state_summary, indent=2)}\n\nDecide the next agent to route to.")
        ])

    routing_history = list(state.get("routing_history", []))
    routing_history.append(f"supervisor → {decision.next_agent.value}")

    return {
        "messages": [
            AIMessage(
                content=(
                    f"[Supervisor] Routing to {decision.next_agent.value}. "
                    f"Reason: {decision.reasoning} "
                    f"(confidence: {decision.confidence:.2f})"
                )
            )
        ],
        "next_agent": decision.next_agent.value,
        "current_agent": "supervisor",
        "routing_history": routing_history,
    }


# =========================================================================
# 2.  INGESTION AGENT
# =========================================================================

def ingestion_node(state: dict) -> dict:
    """
    Data Ingestion Agent — extracts structured remittance data from a raw
    document using the extract_remittance_data tool.
    In production this would call Azure AI Document Intelligence.
    """
    llm = get_llm(temperature=0)
    llm_with_tools = llm.bind_tools([extract_remittance_data])

    raw_doc = state.get("raw_document", "")

    messages = [
        SystemMessage(
            content=(
                "You are the Data Ingestion Agent. Your job is to extract "
                "structured remittance data from the provided document. "
                "Use the extract_remittance_data tool."
            )
        ),
        HumanMessage(content=f"Extract remittance data from:\n\n{raw_doc}"),
    ]

    # Invoke LLM (it will request tool call); then execute tool directly
    _response = llm_with_tools.invoke(messages)
    extracted = extract_remittance_data.invoke({"document_text": raw_doc})

    return {
        "messages": [
            AIMessage(
                content=(
                    "[Ingestion Agent] Extracted remittance data successfully.\n"
                    f"{json.dumps(extracted, indent=2)}"
                )
            )
        ],
        "remittance_data": extracted,
        "current_agent": "ingestion_agent",
        "confidence_scores": {
            **state.get("confidence_scores", {}),
            "ingestion": 0.95,
        },
    }


# =========================================================================
# 3.  REMITTANCE PROCESSING AGENT
# =========================================================================

def remittance_node(state: dict) -> dict:
    """
    Remittance Processing Agent — validates the extracted remittance data
    and looks up each referenced invoice in the ERP system.
    """
    llm = get_llm(temperature=0)
    llm_with_tools = llm.bind_tools([validate_remittance, lookup_invoice])

    remittance_data = state.get("remittance_data", {})

    # Step 1 — Validate remittance data
    validation = validate_remittance.invoke({"remittance_data": remittance_data})

    if not validation["is_valid"]:
        return {
            "messages": [
                AIMessage(
                    content=f"[Remittance Agent] ❌ Validation failed: {validation['errors']}"
                )
            ],
            "current_agent": "remittance_agent",
            "error_log": state.get("error_log", []) + validation["errors"],
            "confidence_scores": {
                **state.get("confidence_scores", {}),
                "remittance_validation": 0.0,
            },
        }

    # Step 2 — Look up each invoice in ERP
    invoice_refs = remittance_data.get("invoice_references", [])
    payment_records = []
    for ref in invoice_refs:
        record = lookup_invoice.invoke({"invoice_number": ref})
        payment_records.append(record)

    return {
        "messages": [
            AIMessage(
                content=(
                    f"[Remittance Agent] ✓ Validated remittance. "
                    f"Retrieved {len(payment_records)} invoice records from ERP."
                )
            )
        ],
        "payment_records": payment_records,
        "current_agent": "remittance_agent",
        "confidence_scores": {
            **state.get("confidence_scores", {}),
            "remittance_validation": 0.92,
        },
    }


# =========================================================================
# 4.  PAYMENT MATCHING AGENT
# =========================================================================

def matching_node(state: dict) -> dict:
    """
    Payment Matching Agent — matches each remittance line item against its
    corresponding invoice using the match_payment tool. Computes per-item
    and overall confidence scores.
    """
    remittance_data = state.get("remittance_data", {})
    payment_records = state.get("payment_records", [])

    match_results = []
    for record in payment_records:
        if "error" in record:
            match_results.append({
                "invoice_number": record.get("invoice_number", "unknown"),
                "remittance_amount": 0,
                "invoice_amount": 0,
                "match_status": "not_found",
                "confidence_score": 0.0,
                "variance": 0,
            })
            continue

        result = match_payment.invoke({
            "remittance_amount": record["amount_due"],
            "invoice_amount": record["amount_due"],
            "invoice_number": record["invoice_number"],
        })
        match_results.append(result)

    # Compute aggregates
    matched = [
        r for r in match_results
        if r["match_status"] in ("exact_match", "near_match")
    ]
    unmatched = [
        r for r in match_results
        if r["match_status"] not in ("exact_match", "near_match")
    ]
    overall_confidence = (
        sum(r["confidence_score"] for r in match_results) / len(match_results)
        if match_results else 0
    )
    requires_hitl = (
        overall_confidence < CONFIDENCE_THRESHOLD_HITL or len(unmatched) > 0
    )

    report = {
        "remittance_id": remittance_data.get("remittance_id", ""),
        "total_matched": len(matched),
        "total_unmatched": len(unmatched),
        "total_amount_matched": sum(r["remittance_amount"] for r in matched),
        "total_amount_unmatched": sum(r.get("remittance_amount", 0) for r in unmatched),
        "match_results": match_results,
        "overall_confidence": round(overall_confidence, 2),
        "requires_human_review": requires_hitl,
    }

    return {
        "messages": [
            AIMessage(
                content=(
                    f"[Matching Agent] Completed: {len(matched)} matched, "
                    f"{len(unmatched)} unmatched. "
                    f"Overall confidence: {overall_confidence:.2f}"
                )
            )
        ],
        "match_results": match_results,
        "matching_report": report,
        "current_agent": "matching_agent",
        "confidence_scores": {
            **state.get("confidence_scores", {}),
            "matching": round(overall_confidence, 2),
        },
        "requires_hitl": requires_hitl,
    }


# =========================================================================
# 5.  SMART MATCHING AGENT
# =========================================================================

def smart_matching_node(state: dict) -> dict:
    """
    Smart Matching Agent — handles unresolved items using fuzzy matching
    and alternative ERP searches. Uses a slightly higher temperature for
    creative matching strategies.
    """
    match_results = list(state.get("match_results", []))
    remittance_data = state.get("remittance_data", {})

    unmatched = [
        r for r in match_results
        if r.get("match_status") not in ("exact_match", "near_match")
    ]

    if not unmatched:
        return {
            "messages": [
                AIMessage(content="[Smart Matching] No unmatched items to process.")
            ],
            "current_agent": "smart_matching_agent",
            "confidence_scores": {
                **state.get("confidence_scores", {}),
                "smart_matching": 1.0,
            },
        }

    # Search ERP for alternative matches
    payer = remittance_data.get("payer_name", "Unknown")
    for item in unmatched:
        alternatives = search_erp_for_alternatives.invoke({
            "payer_name": payer,
            "amount": item.get("remittance_amount", 0),
        })
        item["alternatives_found"] = alternatives
        item["smart_match_confidence"] = 0.75 if alternatives else 0.30

    overall = (
        sum(i.get("smart_match_confidence", 0) for i in unmatched) / len(unmatched)
        if unmatched else 0
    )
    requires_hitl = overall < CONFIDENCE_THRESHOLD_AUTO

    return {
        "messages": [
            AIMessage(
                content=(
                    f"[Smart Matching] Processed {len(unmatched)} unmatched items. "
                    f"Smart confidence: {overall:.2f}. "
                    f"HITL required: {requires_hitl}"
                )
            )
        ],
        "match_results": match_results,
        "current_agent": "smart_matching_agent",
        "confidence_scores": {
            **state.get("confidence_scores", {}),
            "smart_matching": round(overall, 2),
        },
        "requires_hitl": requires_hitl,
    }


# =========================================================================
# 6.  HUMAN-IN-THE-LOOP REVIEW NODE
# =========================================================================

def hitl_node(state: dict) -> dict:
    """
    HITL Review Node — presents a review summary to a human reviewer.
    The graph is compiled with interrupt_before=["hitl_review"] so
    execution pauses BEFORE this node runs, giving the human a chance
    to inspect state and approve / reject / modify.
    """
    report = state.get("matching_report", {})
    confidence = state.get("confidence_scores", {})

    review_summary = (
        "═" * 50 + "\n"
        "  HUMAN REVIEW REQUIRED\n"
        "═" * 50 + "\n"
        f"  Remittance ID     : {report.get('remittance_id', 'N/A')}\n"
        f"  Total Matched     : {report.get('total_matched', 0)}\n"
        f"  Total Unmatched   : {report.get('total_unmatched', 0)}\n"
        f"  Overall Confidence: {report.get('overall_confidence', 0):.2f}\n"
        f"  Agent Confidences : {json.dumps(confidence, indent=4)}\n"
        "═" * 50
    )

    return {
        "messages": [
            AIMessage(content=f"[HITL] Review requested.\n{review_summary}")
        ],
        "current_agent": "hitl_review",
        "hitl_decision": "pending",
    }


# =========================================================================
# 7.  ERROR HANDLER NODE
# =========================================================================

def error_handler_node(state: dict) -> dict:
    """
    Error Handler — applies retry logic. If retries are exhausted (≥ 3),
    escalates to HITL. Otherwise increments retry_count and clears
    the error log so the pipeline can re-attempt.
    """
    errors = state.get("error_log", [])
    retry_count = state.get("retry_count", 0)

    if retry_count >= 3:
        return {
            "messages": [
                AIMessage(
                    content=(
                        f"[Error Handler] Max retries ({retry_count}) exceeded. "
                        f"Escalating to HITL. Errors: {errors}"
                    )
                )
            ],
            "requires_hitl": True,
            "current_agent": "error_handler",
            "next_agent": AgentTarget.HITL.value,
        }

    return {
        "messages": [
            AIMessage(
                content=(
                    f"[Error Handler] Retry attempt {retry_count + 1}/3. "
                    f"Clearing {len(errors)} error(s) for re-processing."
                )
            )
        ],
        "retry_count": retry_count + 1,
        "current_agent": "error_handler",
        "error_log": [],   # Clear errors for retry
    }
