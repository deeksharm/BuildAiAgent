"""
validate.py — Final Lab Validation Script
Lab 2: Multi-Agent Orchestration with LangGraph + Azure AI Foundry

Runs 8 automated checks to verify every exercise requirement is met:
  1. Package Imports
  2. State Definition
  3. Structured Output Models
  4. Tool Definitions
  5. Graph Compilation
  6. Retry & Timeout Policies
  7. Agent Routing Logic
  8. Confidence Thresholds
"""

import sys
import json


def validate_orchestration() -> bool:
    """Run all validation checks and return True if all pass."""

    print("=" * 70)
    print("   VALIDATION: Lab 2 — Multi-Agent Orchestration Skeleton")
    print("=" * 70)

    checks = []

    # ── Check 1: Package Imports ─────────────────────────────────────
    print("\n  Check 1: Package Imports")
    try:
        from langgraph.graph import StateGraph, START, END
        from langgraph.graph.message import add_messages
        from langgraph.checkpoint.memory import MemorySaver
        from langgraph.types import RetryPolicy, Command
        from langchain_openai import AzureChatOpenAI
        from langchain_core.tools import tool
        from pydantic import BaseModel
        print("    ✅ All packages imported successfully.")
        checks.append(("Package Imports", True))
    except ImportError as e:
        print(f"    ❌ Import error: {e}")
        checks.append(("Package Imports", False))

    # ── Check 2: State Definition ────────────────────────────────────
    print("\n  Check 2: State Definition")
    try:
        from state import RemittanceState
        required_keys = [
            "messages", "raw_document", "remittance_data", "payment_records",
            "match_results", "matching_report", "current_agent", "next_agent",
            "routing_history", "confidence_scores", "error_log", "retry_count",
            "requires_hitl", "hitl_decision", "final_output",
        ]
        annotations = RemittanceState.__annotations__
        missing = [k for k in required_keys if k not in annotations]
        if missing:
            print(f"    ⚠️  Missing state keys: {missing}")
            checks.append(("State Definition", False))
        else:
            print(f"    ✅ State has {len(annotations)} fields — all {len(required_keys)} required keys present.")
            checks.append(("State Definition", True))
    except Exception as e:
        print(f"    ❌ Error: {e}")
        checks.append(("State Definition", False))

    # ── Check 3: Structured Output Models ────────────────────────────
    print("\n  Check 3: Structured Output Models (Pydantic)")
    try:
        from models import RoutingDecision, RemittanceAdvice, MatchResult, MatchingReport, AgentOutput

        test_decision = RoutingDecision(
            next_agent="ingestion_agent",
            reasoning="Starting pipeline — raw document needs ingestion",
            confidence=0.95,
        )
        assert test_decision.next_agent.value == "ingestion_agent"
        assert 0 <= test_decision.confidence <= 1

        test_match = MatchResult(
            invoice_number="INV-1001",
            remittance_amount=5000.0,
            invoice_amount=5000.0,
            match_status="exact_match",
            confidence_score=1.0,
            variance=0.0,
        )
        assert test_match.match_status == "exact_match"

        print(f"    ✅ RoutingDecision: next_agent={test_decision.next_agent.value}, confidence={test_decision.confidence}")
        print(f"    ✅ MatchResult: status={test_match.match_status}, confidence={test_match.confidence_score}")
        checks.append(("Structured Outputs", True))
    except Exception as e:
        print(f"    ❌ Error: {e}")
        checks.append(("Structured Outputs", False))

    # ── Check 4: Tool Definitions ────────────────────────────────────
    print("\n  Check 4: Tool Definitions")
    try:
        from tools import (
            extract_remittance_data, validate_remittance,
            lookup_invoice, match_payment, search_erp_for_alternatives, post_to_erp,
        )

        invoice = lookup_invoice.invoke({"invoice_number": "INV-1001"})
        assert invoice["amount_due"] == 5000.00
        print(f"    ✅ lookup_invoice('INV-1001') → amount_due={invoice['amount_due']}")

        match = match_payment.invoke({
            "remittance_amount": 5000, "invoice_amount": 5000, "invoice_number": "INV-1001",
        })
        assert match["match_status"] == "exact_match"
        assert match["confidence_score"] == 1.0
        print(f"    ✅ match_payment(5000, 5000) → {match['match_status']} (confidence={match['confidence_score']})")

        validation = validate_remittance.invoke({"remittance_data": {
            "remittance_id": "R1", "payer_name": "Test", "total_amount": 100,
            "currency": "USD", "invoice_references": ["INV-1"],
        }})
        assert validation["is_valid"] is True
        print(f"    ✅ validate_remittance → is_valid={validation['is_valid']}")

        checks.append(("Tool Definitions", True))
    except Exception as e:
        print(f"    ❌ Error: {e}")
        checks.append(("Tool Definitions", False))

    # ── Check 5: Graph Compilation ───────────────────────────────────
    print("\n  Check 5: Graph Compilation")
    try:
        from graph import build_graph
        g = build_graph()

        # Verify the graph has all expected nodes
        node_names = set(g.nodes.keys()) if hasattr(g, "nodes") else set()
        expected_nodes = {
            "supervisor", "ingestion_agent", "remittance_agent",
            "matching_agent", "smart_matching_agent", "hitl_review", "error_handler",
        }
        missing_nodes = expected_nodes - node_names
        if missing_nodes:
            print(f"    ⚠️  Missing nodes: {missing_nodes}")
            checks.append(("Graph Compilation", False))
        else:
            print(f"    ✅ Graph compiled with {len(node_names)} nodes: {sorted(node_names)}")
            checks.append(("Graph Compilation", True))
    except Exception as e:
        print(f"    ❌ Error: {e}")
        checks.append(("Graph Compilation", False))

    # ── Check 6: Retry & Timeout Policies ────────────────────────────
    print("\n  Check 6: Retry & Timeout Policies")
    try:
        from langgraph.types import RetryPolicy
        from graph import llm_retry_policy

        assert llm_retry_policy.max_attempts == 3
        assert llm_retry_policy.backoff_factor == 2.0
        print(f"    ✅ RetryPolicy: max_attempts={llm_retry_policy.max_attempts}, "
              f"backoff_factor={llm_retry_policy.backoff_factor}, "
              f"initial_interval={llm_retry_policy.initial_interval}s")
        checks.append(("Retry Policy", True))
    except Exception as e:
        print(f"    ❌ Error: {e}")
        checks.append(("Retry Policy", False))

    # ── Check 7: Agent Routing Logic ─────────────────────────────────
    print("\n  Check 7: Agent Routing Logic")
    try:
        from graph import route_from_supervisor, route_after_matching, route_after_smart_matching
        from langgraph.graph import END

        # Supervisor routes to correct targets
        r1 = route_from_supervisor({"next_agent": "ingestion_agent"})
        assert r1 == "ingestion_agent", f"Expected 'ingestion_agent', got '{r1}'"
        print(f"    ✅ route_from_supervisor(next='ingestion_agent') → '{r1}'")

        r2 = route_from_supervisor({"next_agent": "complete"})
        assert r2 == END, f"Expected END, got '{r2}'"
        print(f"    ✅ route_from_supervisor(next='complete') → END")

        r3 = route_from_supervisor({"next_agent": "invalid_agent"})
        assert r3 == "error_handler", f"Expected 'error_handler', got '{r3}'"
        print(f"    ✅ route_from_supervisor(next='invalid') → 'error_handler'")

        # Matching routes based on confidence
        r4 = route_after_matching({
            "confidence_scores": {"matching": 0.95},
            "requires_hitl": False,
            "matching_report": {"total_unmatched": 0},
        })
        assert r4 == "supervisor", f"Expected 'supervisor', got '{r4}'"
        print(f"    ✅ route_after_matching(confidence=0.95, no HITL) → '{r4}'")

        r5 = route_after_matching({
            "confidence_scores": {"matching": 0.40},
            "requires_hitl": True,
            "matching_report": {"total_unmatched": 2},
        })
        assert r5 == "smart_matching_agent", f"Expected 'smart_matching_agent', got '{r5}'"
        print(f"    ✅ route_after_matching(confidence=0.40, unmatched=2) → '{r5}'")

        checks.append(("Agent Routing", True))
    except Exception as e:
        print(f"    ❌ Error: {e}")
        checks.append(("Agent Routing", False))

    # ── Check 8: Confidence Thresholds ───────────────────────────────
    print("\n  Check 8: Confidence Thresholds")
    try:
        from agents import CONFIDENCE_THRESHOLD_AUTO, CONFIDENCE_THRESHOLD_HITL

        assert CONFIDENCE_THRESHOLD_AUTO == 0.85
        assert CONFIDENCE_THRESHOLD_HITL == 0.50
        assert CONFIDENCE_THRESHOLD_AUTO > CONFIDENCE_THRESHOLD_HITL
        print(f"    ✅ Auto-approve threshold : {CONFIDENCE_THRESHOLD_AUTO}")
        print(f"    ✅ HITL escalation threshold: {CONFIDENCE_THRESHOLD_HITL}")
        print(f"    ✅ Correct ordering: AUTO ({CONFIDENCE_THRESHOLD_AUTO}) > HITL ({CONFIDENCE_THRESHOLD_HITL})")
        checks.append(("Confidence Thresholds", True))
    except Exception as e:
        print(f"    ❌ Error: {e}")
        checks.append(("Confidence Thresholds", False))

    # ── Summary ──────────────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("   VALIDATION SUMMARY")
    print("=" * 70 + "\n")

    passed = sum(1 for _, v in checks if v)
    total = len(checks)

    for name, result in checks:
        icon = "✅" if result else "❌"
        print(f"    {icon}  {name}")

    print(f"\n    Result: {passed}/{total} checks passed")

    if passed == total:
        print("\n    🎉 ALL VALIDATIONS PASSED — Lab 2 Complete!")
    else:
        print("\n    ⚠️  Some checks failed. Review the errors above and fix before proceeding.")

    print("\n" + "=" * 70)
    return passed == total


if __name__ == "__main__":
    success = validate_orchestration()
    sys.exit(0 if success else 1)
