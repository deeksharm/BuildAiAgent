"""
graph.py — LangGraph Orchestration Graph Builder
Lab 2: Multi-Agent Orchestration with LangGraph + Azure AI Foundry

Builds and compiles the multi-agent StateGraph with:
  • Supervisor-pattern routing via conditional edges
  • RetryPolicy on all LLM-calling nodes
  • MemorySaver checkpointer for state persistence
  • interrupt_before on the HITL node for human review
"""

from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import RetryPolicy

from state import RemittanceState
from agents import (
    supervisor_node,
    ingestion_node,
    remittance_node,
    matching_node,
    smart_matching_node,
    hitl_node,
    error_handler_node,
    CONFIDENCE_THRESHOLD_AUTO,
    CONFIDENCE_THRESHOLD_HITL,
)


# ── Retry Policy ─────────────────────────────────────────────────────────
# Applied to every LLM-calling node. Handles transient Azure OpenAI errors
# (429 rate-limit, 5xx server errors) with exponential back-off + jitter.

llm_retry_policy = RetryPolicy(
    max_attempts=3,
    initial_interval=1.0,
    backoff_factor=2.0,
    jitter=True,
    retry_on=(Exception,),
)


# ── Routing Functions ────────────────────────────────────────────────────

def route_from_supervisor(state: dict) -> str:
    """
    Route from the Supervisor to the next agent based on the structured
    RoutingDecision written into state['next_agent'].
    Falls back to error_handler if the target is unrecognised.
    """
    next_agent = state.get("next_agent", "complete")

    valid_routes = {
        "ingestion_agent",
        "remittance_agent",
        "matching_agent",
        "smart_matching_agent",
        "hitl_review",
        "complete",
    }

    if next_agent not in valid_routes:
        return "error_handler"

    if next_agent == "complete":
        return END

    return next_agent


def route_after_matching(state: dict) -> str:
    """
    Route after the Matching Agent based on confidence thresholds:
      • confidence ≥ 0.85 and no HITL flag  →  back to Supervisor (finalise)
      • unmatched items remain              →  Smart Matching
      • otherwise                           →  HITL
    """
    confidence = state.get("confidence_scores", {}).get("matching", 0)
    requires_hitl = state.get("requires_hitl", False)
    unmatched = state.get("matching_report", {}).get("total_unmatched", 0)

    if confidence >= CONFIDENCE_THRESHOLD_AUTO and not requires_hitl:
        return "supervisor"
    elif unmatched > 0:
        return "smart_matching_agent"
    else:
        return "hitl_review"


def route_after_smart_matching(state: dict) -> str:
    """
    Route after the Smart Matching Agent:
      • requires_hitl flag set → HITL review
      • otherwise              → back to Supervisor
    """
    if state.get("requires_hitl", False):
        return "hitl_review"
    return "supervisor"


# ── Graph Builder ────────────────────────────────────────────────────────

def build_graph() -> object:
    """
    Build and compile the full multi-agent orchestration graph.

    Graph topology:
                          ┌──────────────┐
                    ┌────→│  Ingestion    │────┐
                    │     └──────────────┘     │
                    │     ┌──────────────┐     │
        START → Supervisor│  Remittance  │←────┤
                    │     └──────────────┘     │
                    │     ┌──────────────┐     │
                    ├────→│  Matching    │─────┤
                    │     └──────┬───────┘     │
                    │            ↓             │
                    │     ┌──────────────┐     │
                    ├────→│Smart Matching│─────┤
                    │     └──────────────┘     │
                    │     ┌──────────────┐     │
                    ├────→│  HITL Review │─────┤
                    │     └──────────────┘     │
                    │     ┌──────────────┐     │
                    └────→│Error Handler │─────┘
                          └──────────────┘
                               ↓
                              END
    """
    builder = StateGraph(RemittanceState)

    # ── Add Nodes (with retry policies on LLM-calling nodes) ─────────
    builder.add_node("supervisor",           supervisor_node,      retry=llm_retry_policy)
    builder.add_node("ingestion_agent",      ingestion_node,       retry=llm_retry_policy)
    builder.add_node("remittance_agent",     remittance_node,      retry=llm_retry_policy)
    builder.add_node("matching_agent",       matching_node,        retry=llm_retry_policy)
    builder.add_node("smart_matching_agent", smart_matching_node,  retry=llm_retry_policy)
    builder.add_node("hitl_review",          hitl_node)
    builder.add_node("error_handler",        error_handler_node)

    # ── Entry Point ──────────────────────────────────────────────────
    builder.add_edge(START, "supervisor")

    # ── Supervisor → Specialists (conditional routing) ───────────────
    builder.add_conditional_edges(
        "supervisor",
        route_from_supervisor,
        {
            "ingestion_agent":      "ingestion_agent",
            "remittance_agent":     "remittance_agent",
            "matching_agent":       "matching_agent",
            "smart_matching_agent": "smart_matching_agent",
            "hitl_review":          "hitl_review",
            "error_handler":        "error_handler",
            END:                    END,
        },
    )

    # ── Specialist → Supervisor (linear return edges) ────────────────
    builder.add_edge("ingestion_agent",  "supervisor")
    builder.add_edge("remittance_agent", "supervisor")

    # ── Matching → conditional (threshold-based routing) ─────────────
    builder.add_conditional_edges(
        "matching_agent",
        route_after_matching,
        {
            "supervisor":           "supervisor",
            "smart_matching_agent": "smart_matching_agent",
            "hitl_review":          "hitl_review",
        },
    )

    # ── Smart Matching → conditional ─────────────────────────────────
    builder.add_conditional_edges(
        "smart_matching_agent",
        route_after_smart_matching,
        {
            "supervisor": "supervisor",
            "hitl_review": "hitl_review",
        },
    )

    # ── HITL & Error Handler → Supervisor ────────────────────────────
    builder.add_edge("hitl_review",   "supervisor")
    builder.add_edge("error_handler", "supervisor")

    # ── Compile with checkpointer + HITL interrupt ───────────────────
    checkpointer = MemorySaver()
    graph = builder.compile(
        checkpointer=checkpointer,
        interrupt_before=["hitl_review"],   # Pause for human approval
    )

    return graph
