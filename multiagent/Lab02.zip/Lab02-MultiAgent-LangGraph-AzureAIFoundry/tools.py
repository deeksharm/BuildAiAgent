"""
tools.py — Tool Definitions for the Multi-Agent Pipeline
Lab 2: Multi-Agent Orchestration with LangGraph + Azure AI Foundry

Each tool is a @tool-decorated function that agents can call via .bind_tools().
In production these would hit real Azure services (AI Search, Dynamics 365, etc.).
Here they use realistic simulated data so the skeleton runs end-to-end without
external dependencies.
"""

from typing import List
from langchain_core.tools import tool


# ---------------------------------------------------------------------------
# Tool 1: Extract Remittance Data (Ingestion Agent)
# ---------------------------------------------------------------------------

@tool
def extract_remittance_data(document_text: str) -> dict:
    """Extract structured remittance data from raw document text.
    Parses payer information, amounts, dates, and invoice references.
    In production this calls Azure AI Document Intelligence."""

    # Simulated extraction — mirrors real Document Intelligence output
    return {
        "remittance_id": "REM-2026-001",
        "payer_name": "Contoso Ltd",
        "payer_account": "ACC-98765",
        "total_amount": 15750.00,
        "currency": "USD",
        "payment_date": "2026-08-10",
        "invoice_references": ["INV-1001", "INV-1002", "INV-1003"],
        "notes": "Payment for Q3 professional services",
    }


# ---------------------------------------------------------------------------
# Tool 2: Validate Remittance (Remittance Processing Agent)
# ---------------------------------------------------------------------------

@tool
def validate_remittance(remittance_data: dict) -> dict:
    """Validate remittance data for completeness and format compliance.
    Checks required fields, positive amounts, and valid currency codes."""

    errors: List[str] = []
    required_fields = [
        "remittance_id", "payer_name", "total_amount",
        "currency", "invoice_references",
    ]

    for field in required_fields:
        if field not in remittance_data or not remittance_data[field]:
            errors.append(f"Missing required field: {field}")

    if remittance_data.get("total_amount", 0) <= 0:
        errors.append("Total amount must be positive")

    valid_currencies = {"USD", "EUR", "GBP", "JPY", "CAD", "AUD"}
    if remittance_data.get("currency") not in valid_currencies:
        errors.append(f"Unsupported currency: {remittance_data.get('currency')}")

    return {
        "is_valid": len(errors) == 0,
        "errors": errors,
        "validated_data": remittance_data if len(errors) == 0 else None,
    }


# ---------------------------------------------------------------------------
# Tool 3: Look Up Invoice (Remittance Processing Agent)
# ---------------------------------------------------------------------------

@tool
def lookup_invoice(invoice_number: str) -> dict:
    """Look up invoice details from the ERP system (Dynamics 365) by invoice number.
    Returns amount due, status, and ERP reference."""

    # Simulated ERP database
    invoices_db = {
        "INV-1001": {
            "invoice_number": "INV-1001",
            "amount_due": 5000.00,
            "currency": "USD",
            "status": "open",
            "erp_reference": "ERP-2026-4401",
        },
        "INV-1002": {
            "invoice_number": "INV-1002",
            "amount_due": 7500.00,
            "currency": "USD",
            "status": "open",
            "erp_reference": "ERP-2026-4402",
        },
        "INV-1003": {
            "invoice_number": "INV-1003",
            "amount_due": 3250.00,
            "currency": "USD",
            "status": "open",
            "erp_reference": "ERP-2026-4403",
        },
    }

    if invoice_number in invoices_db:
        return invoices_db[invoice_number]

    return {
        "error": f"Invoice {invoice_number} not found in ERP",
        "invoice_number": invoice_number,
        "status": "not_found",
    }


# ---------------------------------------------------------------------------
# Tool 4: Match Payment (Matching Agent)
# ---------------------------------------------------------------------------

@tool
def match_payment(
    remittance_amount: float,
    invoice_amount: float,
    invoice_number: str,
) -> dict:
    """Match a remittance payment amount against an invoice amount.
    Returns match status (exact, near, partial, overpayment, no_match)
    and a confidence score."""

    variance = round(remittance_amount - invoice_amount, 2)
    variance_pct = (
        abs(variance) / invoice_amount * 100 if invoice_amount > 0 else 100.0
    )

    if variance == 0:
        status, confidence = "exact_match", 1.0
    elif variance_pct <= 1.0:
        status, confidence = "near_match", 0.95
    elif variance > 0:
        status, confidence = "overpayment", 0.70
    elif variance_pct <= 10:
        status, confidence = "partial_match", 0.60
    else:
        status, confidence = "no_match", 0.30

    return {
        "invoice_number": invoice_number,
        "remittance_amount": remittance_amount,
        "invoice_amount": invoice_amount,
        "variance": variance,
        "variance_percentage": round(variance_pct, 2),
        "match_status": status,
        "confidence_score": confidence,
    }


# ---------------------------------------------------------------------------
# Tool 5: Search ERP for Alternatives (Smart Matching Agent)
# ---------------------------------------------------------------------------

@tool
def search_erp_for_alternatives(payer_name: str, amount: float) -> List[dict]:
    """Search ERP (Dynamics 365) for alternative invoice matches
    when standard matching fails. Uses fuzzy search by payer and amount range."""

    # Simulated fuzzy search results
    return [
        {
            "invoice_number": "INV-0998",
            "amount_due": amount,
            "payer": payer_name,
            "status": "open",
            "age_days": 45,
            "match_likelihood": "high",
        },
        {
            "invoice_number": "INV-0877",
            "amount_due": round(amount * 0.95, 2),
            "payer": payer_name,
            "status": "open",
            "age_days": 90,
            "match_likelihood": "medium",
        },
    ]


# ---------------------------------------------------------------------------
# Tool 6: Post to ERP (Final Settlement)
# ---------------------------------------------------------------------------

@tool
def post_to_erp(
    payment_id: str,
    invoice_number: str,
    amount: float,
    status: str,
) -> dict:
    """Post a matched payment to the ERP system (Dynamics 365) for settlement.
    Creates a transaction record and updates invoice status."""

    return {
        "erp_transaction_id": f"TXN-{payment_id}-{invoice_number}",
        "status": "posted",
        "amount": amount,
        "invoice_number": invoice_number,
        "timestamp": "2026-08-13T10:00:00Z",
    }
