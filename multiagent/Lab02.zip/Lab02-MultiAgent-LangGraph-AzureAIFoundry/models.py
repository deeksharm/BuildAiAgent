"""
models.py — Pydantic Structured Output Models
Lab 2: Multi-Agent Orchestration with LangGraph + Azure AI Foundry

These models enforce structured, validated outputs from every agent in the pipeline.
The LLM is bound to these schemas via .with_structured_output() so responses are
guaranteed to conform — no manual parsing required.
"""

from __future__ import annotations
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# 1. Routing — Supervisor uses this to make deterministic routing decisions
# ---------------------------------------------------------------------------

class AgentTarget(str, Enum):
    """Valid routing targets for the Supervisor agent."""
    INGESTION       = "ingestion_agent"
    REMITTANCE      = "remittance_agent"
    MATCHING        = "matching_agent"
    SMART_MATCHING  = "smart_matching_agent"
    HITL            = "hitl_review"
    COMPLETE        = "complete"


class RoutingDecision(BaseModel):
    """Structured output returned by the Supervisor to control agent routing."""
    next_agent: AgentTarget = Field(
        description="The next agent to route the task to"
    )
    reasoning: str = Field(
        description="Brief explanation for the routing decision"
    )
    confidence: float = Field(
        ge=0.0, le=1.0,
        description="Supervisor confidence in this routing decision (0.0–1.0)"
    )


# ---------------------------------------------------------------------------
# 2. Remittance Data — Output of the Ingestion Agent
# ---------------------------------------------------------------------------

class RemittanceAdvice(BaseModel):
    """Structured remittance advice extracted from a raw document."""
    remittance_id: str       = Field(description="Unique remittance identifier")
    payer_name: str          = Field(description="Name of the paying entity")
    payer_account: str       = Field(description="Payer bank/account reference")
    total_amount: float      = Field(description="Total payment amount")
    currency: str            = Field(description="ISO 4217 currency code")
    payment_date: str        = Field(description="Date the payment was issued (YYYY-MM-DD)")
    invoice_references: List[str] = Field(description="List of invoice numbers covered")
    notes: Optional[str]     = Field(default=None, description="Free-text notes from payer")


# ---------------------------------------------------------------------------
# 3. Payment / Invoice Records — Retrieved from ERP
# ---------------------------------------------------------------------------

class PaymentRecord(BaseModel):
    """An invoice / payment record retrieved from the ERP system."""
    payment_id: Optional[str]     = Field(default=None, description="Internal payment ID")
    invoice_number: str            = Field(description="Invoice number")
    amount_due: float              = Field(description="Amount due on the invoice")
    amount_paid: float             = Field(default=0.0, description="Amount already paid")
    currency: str                  = Field(description="Currency code")
    status: str                    = Field(description="Invoice status (open, partial, closed)")
    erp_reference: Optional[str]   = Field(default=None, description="ERP transaction reference")


# ---------------------------------------------------------------------------
# 4. Match Result — Output per invoice from the Matching Agent
# ---------------------------------------------------------------------------

class MatchResult(BaseModel):
    """Result of matching a single remittance line to an invoice."""
    invoice_number: str    = Field(description="Invoice number being matched")
    remittance_amount: float = Field(description="Amount from remittance advice")
    invoice_amount: float  = Field(description="Amount due on the invoice")
    match_status: str      = Field(
        description="Match outcome: exact_match | near_match | partial_match | overpayment | no_match"
    )
    confidence_score: float = Field(
        ge=0.0, le=1.0,
        description="Confidence in this match (0.0–1.0)"
    )
    variance: float        = Field(description="remittance_amount − invoice_amount")
    notes: Optional[str]   = Field(default=None, description="Additional notes")


# ---------------------------------------------------------------------------
# 5. Matching Report — Aggregate output from the Matching Agent
# ---------------------------------------------------------------------------

class MatchingReport(BaseModel):
    """Aggregate matching report for an entire remittance."""
    remittance_id: str               = Field(description="The remittance being processed")
    total_matched: int               = Field(description="Number of invoices matched")
    total_unmatched: int             = Field(description="Number of invoices unmatched")
    total_amount_matched: float      = Field(description="Sum of matched amounts")
    total_amount_unmatched: float    = Field(description="Sum of unmatched amounts")
    match_results: List[MatchResult] = Field(description="Per-invoice match results")
    overall_confidence: float        = Field(
        ge=0.0, le=1.0,
        description="Weighted average confidence across all matches"
    )
    requires_human_review: bool      = Field(description="Whether HITL escalation is needed")
    review_reason: Optional[str]     = Field(
        default=None,
        description="Reason for HITL escalation, if applicable"
    )


# ---------------------------------------------------------------------------
# 6. Generic Agent Output — Standardised wrapper for any agent response
# ---------------------------------------------------------------------------

class AgentOutput(BaseModel):
    """Standardised output wrapper for any agent in the pipeline."""
    agent_name: str         = Field(description="Name of the agent producing this output")
    status: str             = Field(description="Execution status: success | partial | error")
    message: str            = Field(description="Human-readable summary of the result")
    data: Optional[dict]    = Field(default=None, description="Payload data")
    confidence: float       = Field(
        ge=0.0, le=1.0, default=1.0,
        description="Agent confidence in its output"
    )
