"""
state.py — Shared Agent State Definition
Lab 2: Multi-Agent Orchestration with LangGraph + Azure AI Foundry

The RemittanceState TypedDict is the single source of truth that flows through
every node in the LangGraph orchestration graph. Each agent reads from and
writes back to this shared state.
"""

from typing import Annotated, List, Optional, TypedDict
from langgraph.graph.message import add_messages


class RemittanceState(TypedDict):
    """
    Shared state for the multi-agent remittance processing pipeline.

    Fields:
        messages           — Chat message history (auto-appended via add_messages reducer)
        raw_document       — Raw remittance document text awaiting ingestion
        remittance_data    — Structured remittance data after ingestion
        payment_records    — Invoice records retrieved from ERP
        match_results      — Per-invoice match results from the Matching Agent
        matching_report    — Aggregate matching report
        current_agent      — Name of the agent that last executed
        next_agent         — Routing target decided by the Supervisor
        routing_history    — Ordered log of all routing decisions
        confidence_scores  — Per-agent confidence scores {agent_name: score}
        error_log          — Accumulated error messages
        retry_count        — Current retry counter for the error handler
        requires_hitl      — Flag indicating human review is needed
        hitl_decision      — Human reviewer's decision (approved / rejected / modified)
        final_output       — Final processed output after pipeline completion
    """

    # Message history — uses the add_messages reducer to auto-append
    messages: Annotated[list, add_messages]

    # Document & data flow
    raw_document: Optional[str]
    remittance_data: Optional[dict]
    payment_records: Optional[List[dict]]
    match_results: Optional[List[dict]]
    matching_report: Optional[dict]

    # Orchestration control
    current_agent: str
    next_agent: str
    routing_history: List[str]

    # Confidence & quality
    confidence_scores: dict

    # Error handling
    error_log: List[str]
    retry_count: int

    # Human-in-the-Loop
    requires_hitl: bool
    hitl_decision: Optional[str]

    # Final output
    final_output: Optional[dict]
