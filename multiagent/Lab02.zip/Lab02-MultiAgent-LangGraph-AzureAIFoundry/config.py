"""
config.py — Azure OpenAI + Azure AI Foundry Configuration
Lab 2: Multi-Agent Orchestration with LangGraph + Azure AI Foundry
"""

import os
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
from azure.ai.projects import AIProjectClient
from azure.identity import InteractiveBrowserCredential

load_dotenv()

def get_project_client() -> AIProjectClient:
    """
    Create and return an AIProjectClient connected to Azure AI Foundry.
    """
    return AIProjectClient(
        credential=InteractiveBrowserCredential(),
        endpoint=os.environ["AZURE_AI_PROJECT_CONNECTION_STRING"],
    )



def get_llm(temperature: float = 0, max_retries: int = 3, timeout: float = 60.0) -> AzureChatOpenAI:
    """
    Create and return an AzureChatOpenAI instance connected to Azure AI Foundry.

    Args:
        temperature: Controls randomness. 0 = deterministic, 1 = creative.
        max_retries:  HTTP-level retries handled by the OpenAI SDK.
        timeout: HTTP request timeout in seconds.

    Returns:
        AzureChatOpenAI: Configured LLM client.
    """
    return AzureChatOpenAI(
        azure_deployment=os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"],
        azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
        api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2025-04-01-preview"),
        temperature=1,  # Force temperature to 1 to fix the unsupported value error for O1/O3 models
        max_retries=max_retries,
        timeout=timeout,
    )
